package com.raiffeisen.javaschool.boot.orm.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import java.io.Serializable;

@Data
@EqualsAndHashCode(exclude = "customerOption")

@Entity
@Table(name = "customer_option", schema = "public")
public class CustomerOption implements Serializable {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customerOption;

    @Column(name = "option_name", nullable = false)
    private String nameOfOption;

}
