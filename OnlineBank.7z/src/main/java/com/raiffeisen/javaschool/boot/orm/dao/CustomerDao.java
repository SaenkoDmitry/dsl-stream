package com.raiffeisen.javaschool.boot.orm.dao;

import com.raiffeisen.javaschool.boot.orm.model.Customer;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;

@Repository
public class CustomerDao extends PagingAbstractDao<Customer> {
    @Override
    Class getEClass() {
        return Customer.class;
    }

    @Transactional
    public void setAddress(long id, String address) {
        Customer customer = em.find(Customer.class, id);
        if (customer != null) {
            customer.setAddress(address);
        }
    }
}
