package com.raiffeisen.javaschool.boot.orm.conf;

import com.raiffeisen.javaschool.boot.orm.aspect.SimpleProfilerAspect;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@Configuration
@EnableAspectJAutoProxy
@ComponentScan(basePackageClasses = SimpleProfilerAspect.class)
public class AOPConfiguration {
}
