package com.raiffeisen.javaschool.boot.orm.service;

import com.raiffeisen.javaschool.boot.orm.dao.AccountDao;
import com.raiffeisen.javaschool.boot.orm.model.Account;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccountService {

    @Autowired
    AccountDao accountDao;

    private Logger logger = LoggerFactory.getLogger(AccountService.class);

    public List<Account> findAllByNonActiveCard() {

        return accountDao.findAllByNonActiveCard();

    }

}