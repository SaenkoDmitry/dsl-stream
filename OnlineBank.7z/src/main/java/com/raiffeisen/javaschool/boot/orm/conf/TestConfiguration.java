package com.raiffeisen.javaschool.boot.orm.conf;

import com.raiffeisen.javaschool.boot.orm.conf.AOPConfiguration;
import com.raiffeisen.javaschool.boot.orm.conf.ModelConfiguration;
import com.raiffeisen.javaschool.boot.orm.conf.PersistenceTestConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({PersistenceTestConfiguration.class, ModelConfiguration.class, AOPConfiguration.class})
public class TestConfiguration {

}

