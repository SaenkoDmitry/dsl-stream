package com.raiffeisen.javaschool.boot.orm.service;

import com.raiffeisen.javaschool.boot.orm.dao.TransactionHistoryDao;
import com.raiffeisen.javaschool.boot.orm.model.TransactionHistory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.List;

@Service
public class TransactionHistoryService {


    @Autowired
    TransactionHistoryDao transactionHistoryDao;

    public List<TransactionHistory> findAllByExpirationTimeAndAccountId(Long id, Duration duration) {

        return transactionHistoryDao.findAllByExpirationTimeAndAccountId(id, duration);
    }

    public void print(Long id) {

//         transactionHistoryDao.getAllByCardId(id).stream()
//                 .forEach(m -> System.out::println(m));


    }

}