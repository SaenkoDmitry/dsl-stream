package com.raiffeisen.javaschool.boot.orm.dao;

import com.raiffeisen.javaschool.boot.orm.model.Customer;
import com.raiffeisen.javaschool.boot.orm.model.CustomerOption;
import org.springframework.stereotype.Repository;

import javax.persistence.criteria.*;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Repository
public class CustomerOptionDao extends PagingAbstractDao<CustomerOption> {
    @Override
    Class getEClass() {
        return CustomerOption.class;
    }

    @Transactional
    public Collection<String> getCustomerPhoneNumbersWithOption(String... options) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<String> query = cb.createQuery(String.class);
        Root<Customer> from = query.from(Customer.class);

        Join<Customer, CustomerOption> join = from.join("options");

        List<Predicate> predicates = new ArrayList<>();
        for (int i = 0; i < options.length; i++) {
            predicates.add(cb.equal(join.get("nameOfOption"), options[i]));
        }

        query
                .select(from.get("mobile").as(String.class))
                .groupBy(from.get("mobile"))
                .where(
                        cb.or(predicates.toArray(new Predicate[predicates.size()]))
                );

        return list(query);
    }
}
