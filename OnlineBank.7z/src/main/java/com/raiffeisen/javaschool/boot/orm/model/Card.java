package com.raiffeisen.javaschool.boot.orm.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

@Data
@EqualsAndHashCode(exclude = "accountCard")
@ToString
@Entity
@Table(name = "card", schema = "public")
public class Card implements Serializable {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "account_id", nullable = false)
    private Account accountCard;

    @Column(name = "type_of_card", nullable = false)
    private String typeOfCard;

    @Column(name = "exp_date", nullable = false)
    private LocalDate expDate;

    @Column(name = "pin_code", nullable = false)
    private String pinCode;

    @Column(name = "cvv", nullable = false)
    private String cvv;

}
