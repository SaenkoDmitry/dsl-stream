package com.raiffeisen.javaschool.boot.orm.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@Data
@EqualsAndHashCode(exclude = {"customerAcc"})
@ToString(exclude = {"customerAcc", "cards", "transactionHistories"})
@Entity
@Table(name = "account", schema = "public")
public class Account implements Serializable {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "secret", nullable = false)
    private String secret;

    @ManyToOne
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customerAcc;

    @Column(name = "type_of_acc", nullable = false)
    private String typeOfAccount;

    @Column(name = "balance", nullable = false)
    private Long balance;

    @OneToMany(cascade = CascadeType.REMOVE,
            fetch = FetchType.EAGER,
            orphanRemoval = true,
            mappedBy = "accountCard")
    private Set<Card> cards = new HashSet<>();

    @OneToMany(cascade = CascadeType.REMOVE,
            fetch = FetchType.EAGER,
            orphanRemoval = true,
            mappedBy = "accountTransactionHistory")
    private Set<TransactionHistory> transactionHistories = new HashSet<>();

}
