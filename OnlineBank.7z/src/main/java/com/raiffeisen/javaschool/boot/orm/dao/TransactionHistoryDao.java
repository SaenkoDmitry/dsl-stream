package com.raiffeisen.javaschool.boot.orm.dao;

import com.raiffeisen.javaschool.boot.orm.model.Account;
import com.raiffeisen.javaschool.boot.orm.model.Card;
import com.raiffeisen.javaschool.boot.orm.model.TransactionHistory;
import org.springframework.stereotype.Repository;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;
import java.time.Duration;
import java.time.Instant;
import java.util.List;

@Repository
public class TransactionHistoryDao extends PagingAbstractDao<TransactionHistory> {
    @Override
    Class getEClass() {
        return TransactionHistory.class;
    }

    @Transactional
    public List<TransactionHistory> findAllByExpirationTimeAndAccountId(Long id, Duration duration) {
        return searchList(new SearchFilter() {
            @Override
            public Predicate buildPredicate(CriteriaBuilder criteriaBuilder, Root<TransactionHistory> root) {
                Instant startTime = Instant.now().minus(duration);

                Predicate p1 = criteriaBuilder.greaterThan(root.get("timeOfOperation"), startTime);
                Predicate p2 = criteriaBuilder.equal(root.get("accountTransactionHistory"), id);
                Predicate p3 = criteriaBuilder.equal(root.get("state"), "\'PASS\'");

                return criteriaBuilder.and(p1, p2, p3);
            }
        });
    }

    @Transactional
    public List<TransactionHistory> getAllByCardId(Long id) {
        return searchList(new SearchFilter() {
            @Override
            public Predicate buildPredicate(CriteriaBuilder criteriaBuilder, Root<TransactionHistory> root) {
                Join<TransactionHistory, Account> firstJoin = root.join("accountTransactionHistory");
                Join<Account, Card> secondJoin = firstJoin.join("cards");

                return criteriaBuilder.equal(secondJoin.get("id"), id);
            }
        });


//        return em
//                .createQuery("from TransactionHistory tHistory " +
//                        "join " +
//                        "Account acc " +
//                        "on tHistory.accountTransactionHistory.id = acc.id " +
//                        "join " +
//                        "Card card " +
//                        "on card.accountCard.id = acc.id " +
//                        "where card.id = :id")
//                .setParameter("id", id)
//                .getResultList();
    }
}
