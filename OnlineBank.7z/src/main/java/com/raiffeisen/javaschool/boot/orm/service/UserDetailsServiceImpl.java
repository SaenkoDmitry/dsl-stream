package com.raiffeisen.javaschool.boot.orm.service;

import lombok.Data;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.concurrent.ConcurrentHashMap;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {
    private ConcurrentHashMap<String, UserObject> cached = new ConcurrentHashMap<>();
    public UserDetailsServiceImpl() {
        GrantedAuthority a = new SimpleGrantedAuthority("admin");
        cached.put("admin", new UserObject("admin", "admin", "admin"));
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        UserObject user = cached.get(username);
        UserDetails userDetails = User.withUsername(user.getName())
                .password(user.getPassword())
                .roles(user.getPassword())
                .build();
        return userDetails;
    }

    @Data
    private static class UserObject {
        private String name;
        private String password;
        private String role;

        public UserObject(String name, String password, String role) {
            this.name = name;
            this.password = password;
            this.role = role;
        }
    }
}
