package com.raiffeisen.javaschool.boot.orm.dao;

import com.raiffeisen.javaschool.boot.orm.model.Account;
import com.raiffeisen.javaschool.boot.orm.model.Card;
import com.raiffeisen.javaschool.boot.orm.model.Customer;
import org.springframework.stereotype.Repository;

import javax.persistence.criteria.*;
import javax.transaction.Transactional;
import java.util.List;

@Repository
public class CardDao extends PagingAbstractDao<Card> {
    @Override
    Class getEClass() {
        return Card.class;
    }

    @Transactional
    public Customer findOwner(long id) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Customer> query = cb.createQuery(Customer.class);
        Root<Customer> from = query.from(Customer.class);

        Join<Customer, Account> selectedAccounts = from.join("accounts");
        Join<Account, Card> selectedCustomers = selectedAccounts.join("cards");

        query
                .select(from)
                .where(
                        cb.equal(selectedCustomers.get("id"), id)
                );

        return single(query);
    }

    @Transactional
    public List<Card> cardsWithNegativeBalance() {
        return searchList(new SearchFilter() {
            @Override
            public Predicate buildPredicate(CriteriaBuilder criteriaBuilder, Root<Card> root) {
                Join<Card, Account> selectedAccounts = root.join("accountCard");
                return criteriaBuilder.lt(selectedAccounts.get("balance"), 0);
            }
        });
    }
}