package com.raiffeisen.javaschool.boot.orm.service;

import com.raiffeisen.javaschool.boot.orm.dao.CustomerDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {

    @Autowired
    CustomerDao customerDao;

    public void setAddress(long id, String address) {

        customerDao.setAddress(id, address);

    }

}
