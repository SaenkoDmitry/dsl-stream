package com.raiffeisen.javaschool.boot.orm.conf;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({PersistenceDevConfiguration.class, ModelConfiguration.class})
public class DevConfiguration {

}

