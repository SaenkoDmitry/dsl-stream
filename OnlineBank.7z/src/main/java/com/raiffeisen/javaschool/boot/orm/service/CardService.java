package com.raiffeisen.javaschool.boot.orm.service;

import com.raiffeisen.javaschool.boot.orm.dao.CardDao;
import com.raiffeisen.javaschool.boot.orm.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CardService {

    @Autowired
    CardDao cardDao;

    public Customer findOwner(long id) {

        return cardDao.findOwner(id);
    }


}
