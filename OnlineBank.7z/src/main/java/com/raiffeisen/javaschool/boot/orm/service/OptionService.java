package com.raiffeisen.javaschool.boot.orm.service;

import org.springframework.stereotype.Service;

@Service
public class OptionService {


}
