package com.raiffeisen.javaschool.boot.orm.controller;

import org.springframework.stereotype.Controller;

@Controller
public class AccountController {
}
