package com.raiffeisen.javaschool.boot.orm.conf;

import com.raiffeisen.javaschool.boot.orm.model.Account;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@ComponentScan(basePackageClasses = Account.class)
public class ModelConfiguration {
}
