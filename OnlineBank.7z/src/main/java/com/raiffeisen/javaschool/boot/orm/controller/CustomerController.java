package com.raiffeisen.javaschool.boot.orm.controller;

import com.raiffeisen.javaschool.boot.orm.dao.CustomerDao;
import com.raiffeisen.javaschool.boot.orm.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.websocket.server.PathParam;
import javax.xml.ws.Response;
import java.util.List;

@RestController
@RequestMapping("customers")
public class CustomerController {
    @Autowired
    CustomerDao customerDao;

    @GetMapping(value = "/", produces = "application/json")
    @PreAuthorize("hasAnyRole('admin','user')")
    public @ResponseBody List<Customer> getCustomers() {
        List<Customer> customers = customerDao.findAll();
        return customers;
    }

    @GetMapping(value = "/someAction", produces = "application/json")
    public @ResponseBody List<Customer> getCustomerSomeAction() {
        List<Customer> customers = customerDao.findAll();
        return customers;
    }

    @GetMapping("/{id}")
    public @ResponseBody ResponseEntity getCustomer(@PathVariable("id") Long id) {

        Customer customer = customerDao.findById(id);
        if (customer == null) {
            return new ResponseEntity("No Customer found for ID " + id, HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity(customer, HttpStatus.OK);
    }

    @PostMapping("/")
    public @ResponseBody ResponseEntity createCustomer(@PathParam("customer") Customer customer) {

        customerDao.create(customer);
        return new ResponseEntity(HttpStatus.OK);
    }
}
