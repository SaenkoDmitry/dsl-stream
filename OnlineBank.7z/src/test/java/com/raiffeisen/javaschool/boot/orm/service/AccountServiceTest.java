package com.raiffeisen.javaschool.boot.orm.service;

import static org.testng.Assert.*;

public class AccountServiceTest {

}