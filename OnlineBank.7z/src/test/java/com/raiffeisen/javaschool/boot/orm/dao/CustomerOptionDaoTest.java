package com.raiffeisen.javaschool.boot.orm.dao;

import com.raiffeisen.javaschool.boot.orm.conf.TestConfiguration;
import com.raiffeisen.javaschool.boot.orm.model.CustomerOption;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Collection;
import java.util.List;

import static org.testng.Assert.*;

@ContextConfiguration(classes = TestConfiguration.class)
public class CustomerOptionDaoTest  extends AbstractTestNGSpringContextTests {

    @Autowired
    private CustomerOptionDao customerOptionDao;

    @Autowired
    private CustomerDao customerDao;

    @Test(groups = "first")
    public void testGetCustomerPhoneNumbersWithOption() {
        Collection<String> customerPhones = customerOptionDao.getCustomerPhoneNumbersWithOption("SMS", "AUTO PAYMENT");
        Assert.assertEquals(customerPhones.size(), 1);
    }

    @Test(groups = "first")
    public void testFindAll() {
        List<CustomerOption> customerOptions = customerOptionDao.findAll();
        assertEquals(customerOptions.size(), 2);
    }

    @Test(groups = "first")
    public void testFindById() {
        CustomerOption customerOption = customerOptionDao.findById(56L);
        assertNotNull(customerOption);
    }

    @Test(groups = "first")
    public void testUpdate() {
        CustomerOption customerOption = customerOptionDao.findById(56L);
        customerOption.setNameOfOption("OLOLO");
        customerOptionDao.update(customerOption);
        assertEquals(customerOption.getNameOfOption(), "OLOLO");

    }

    @Test(groups = "third")
    public void testDelete() {
        int before = customerOptionDao.findAll().size();
        customerOptionDao.delete(59L);
        int after = customerOptionDao.findAll().size();
        Assert.assertEquals(before - 1, after);

    }

    @Test(groups = "second")
    public void testCreate() {
        CustomerOption customerOption = new CustomerOption();
        customerOption.setNameOfOption("temp");
        customerOption.setCustomerOption(customerDao.findById(34L));

        customerOptionDao.create(customerOption);

    }

    @Test(groups = "first")
    public void getCustomerPhoneNumbersWithOptionTest() {
        Collection<String> sms = customerOptionDao.getCustomerPhoneNumbersWithOption("SMS");

        assertEquals(sms.size(), 1);

    }


}