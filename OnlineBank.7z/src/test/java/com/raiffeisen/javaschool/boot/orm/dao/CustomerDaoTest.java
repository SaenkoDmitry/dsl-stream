package com.raiffeisen.javaschool.boot.orm.dao;

import com.raiffeisen.javaschool.boot.orm.conf.TestConfiguration;
import com.raiffeisen.javaschool.boot.orm.model.Account;
import com.raiffeisen.javaschool.boot.orm.model.Customer;
import com.raiffeisen.javaschool.boot.orm.model.CustomerOption;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;

@ContextConfiguration(classes = TestConfiguration.class)
public class CustomerDaoTest extends AbstractTestNGSpringContextTests {

    @Autowired
    private CustomerDao customerDao;

    @Test(groups = "second")
    public void testCreate() {

        int before = customerDao.findAll().size();

        //Account:
        Account account = new Account();
        account.setBalance(1_000_000L);
        account.setSecret("123");
        account.setTypeOfAccount("123");
        HashSet<Account> accounts = new HashSet<>();
        accounts.add(account);


        //CustomerOption
        CustomerOption customerOption = new CustomerOption();
        customerOption.setNameOfOption("SMS");
        HashSet<CustomerOption> customerOptions = new HashSet<>();

        //Customer (Contains accounts and options)
        Customer customer = new Customer();
        customer.setFirstName("Sergey");
        customer.setLastName("Shnurov");
        customer.setGender('M');
        customer.setMobile("88005553535");
        customer.setAddress("Sovetskiy Soyuz");
        customer.setPassword("1234");
        customer.setEmail("www_leningrad_www.ru");
        customer.setLogin("test");
        customer.setBirthday(LocalDate.of(10, 10, 10));
        customer.setAccounts(accounts);
        customer.setOptions(customerOptions);


        account.setCustomerAcc(customer);
        customerOption.setCustomerOption(customer);


        customerDao.create(customer);
        Long customerId = customer.getId();

        int after = customerDao.findAll().size();

        assertEquals(before + 1, after);
        assertNotNull(customerDao.findById(customerId));

    }

    @Test(groups = "first")
    public void testSetAddress() {
        customerDao.setAddress(36L, "London");
        Customer customer = customerDao.findById(36L);
        assertEquals(customer.getAddress(), "London");
    }

    @Test(groups = "first")
    public void testFindAll() {
        List<Customer> customers = customerDao.findAll();
        assertEquals(customers.size(), 3);
    }

    @Test(groups = "first")
    public void testFindById() {
        Customer customer = customerDao.findById(36L);
        assertNotNull(customer);
    }

    @Test(groups = "first")
    public void testUpdate() {
        Customer customer = customerDao.findById(36L);
        customer.setFirstName("Sergey");
        customer.setLastName("Shnurov");
        customerDao.update(customer);
        assertEquals(customer.getFirstName(), "Sergey");
        assertEquals(customer.getLastName(), "Shnurov");
    }

    @Test(groups = "third")
    public void testDelete() {
        int before = customerDao.findAll().size();
        customerDao.delete(35L);
        int after = customerDao.findAll().size();
        Assert.assertNotEquals(before, after);
    }

}