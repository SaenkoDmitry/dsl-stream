package com.raiffeisen.javaschool.boot.orm.dao;

import com.raiffeisen.javaschool.boot.orm.conf.TestConfiguration;
import com.raiffeisen.javaschool.boot.orm.model.Card;
import com.raiffeisen.javaschool.boot.orm.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.LocalDate;
import java.util.List;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;


@ContextConfiguration(classes = TestConfiguration.class)
public class CardDaoTest extends AbstractTestNGSpringContextTests {

    @Autowired
    private CardDao cardDao;

    @Autowired
    private AccountDao accountDao;

    @Test(groups = "first")
    public void testFindById() {
        Card card = cardDao.findById(200L);
        assertNotNull(card);
    }

    @Test(groups = "second")
    public void testCreate() {

        int before = cardDao.findAll().size();
        Card card = new Card();
        card.setAccountCard(accountDao.findById(56L));
        card.setCvv("124");
        card.setPinCode("1234");
        card.setTypeOfCard("debit");
        card.setExpDate(LocalDate.now());

        cardDao.create(card);

        Long id = card.getId();

        int after = cardDao.findAll().size();
        assertEquals(before + 1, after);
        Assert.assertNotNull(cardDao.findById(id));

        Card persistedCard = cardDao.findById(id);
        assertEquals("124", persistedCard.getCvv());
        assertEquals("1234", persistedCard.getPinCode());
        assertEquals("debit", persistedCard.getTypeOfCard());
        assertEquals("28a1b310b43643306f560bb161ff6b67f763c576", persistedCard.getAccountCard().getSecret());

    }

    @Test(groups = "first")
    public void testUpdate() {
        Card persistedCard = cardDao.findById(203L);
        persistedCard.setPinCode("1111");
        persistedCard.setTypeOfCard("VISA");

        cardDao.update(persistedCard);

        Card updatedCard = cardDao.findById(203L);

        assertNotNull(updatedCard);
        assertEquals(updatedCard.getPinCode(), "1111");
        assertEquals(updatedCard.getTypeOfCard(), "VISA");
        assertEquals(updatedCard.getCvv(), "234");

    }

    @Test(groups = "third")
    public void testDelete() {
        int before = cardDao.findAll().size();
        cardDao.delete(201L);
        int after = cardDao.findAll().size();
        Assert.assertEquals(before - 1, after);

    }

    @Test(groups = "first")
    public void testFindOwner() {
        Customer owner = cardDao.findOwner(200);
        assertEquals(owner.getFirstName(), "Vasiliy");
    }

    @Test(groups = "first")
    public void testFindAll() {
        List<Card> allCards = cardDao.findAll();
        assertEquals(allCards.size(), 3);
    }


    @Test(groups = "first")
    public void testCardsWithNegativeBalance() {
        List<Card> cards = cardDao.cardsWithNegativeBalance();
        assertEquals(cards.size(), 0);
    }
}