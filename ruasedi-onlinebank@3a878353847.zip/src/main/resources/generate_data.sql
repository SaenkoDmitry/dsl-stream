INSERT INTO `CUSTOMER` (`ID`, `FIRST_NAME`, `LAST_NAME`, `MIDDLE_NAME`, `GENDER`, `BIRTHDAY`, `ADDRESS`, `MOBILE`, `EMAIL`, `PASSWORD`, `LOGIN`) VALUES
(34, 'Vasiliy', 'Petrov', 'Petrovich', 'M', '1993-12-30',  'moscow', '9999955555', 'vasya@gmail.com', '28a1b310b43643306f560bb161ff6b67f763c576', 'LOGIN'),
(35, 'Vitaliy', 'Kozlov','Petrovich', 'M', '1990-12-26',  'moscow', '9999955556', 'leha@gmail.com', '28a1b310b43643306f560bb161ff6b67f763c576', 'LOGIN'),
(36, 'Viktor', ' Nemtzov','Petrovich', 'M', '1993-06-26',  'moscow', '9999955556', 'kias@gmail.com', '28a1b310b43643306f560bb161ff6b67f763c576', 'LOGIN'),
(37, 'Artem', 'Pavlov','Petrovich', 'M', '1993-06-26',  'moscow', '9999955556', 'opra@gmail.com', '28a1b310b43643306f560bb161ff6b67f763c576', 'LOGIN'),
(38, 'Aleksandra', 'Olovenova', 'Petrovich','F',  '1993-06-26', 'moscow', '9999955556', 'legamc@gmail.com', '28a1b310b43643306f560bb161ff6b67f763c576', 'LOGIN'),
(39, 'Kiril', 'Shvedov','Petrovich', 'M', '2015-01-14',  'moscow', '9804381248', 'sunny@gmail.com', '28a1b310b43643306f560bb161ff6b67f763c576', 'LOGIN'),
(40, 'Diana', 'Alieva', 'Petrovich','F', '1996-02-18', 'moscow', '8956231245', 'alex99@gmail.com', '28a1b310b43643306f560bb161ff6b67f763c576', 'LOGIN'),
(41, 'Evgeniy', 'Trebnikov', 'Petrovich','M', '1993-12-26', 'moscow', '8956231245', 'sarik_adreasyan@gmail.com', 'b638866443ed874cd5a9449a090cb8dce66e4a3a', 'LOGIN');

INSERT INTO `ACCOUNT` (`ID`, `CUSTOMER_ID`,  `TYPE_OF_ACC`, `BALANCE`, `SECRET`) VALUES
(56, 34, 'savings', 12342.12, '28a1b310b43643306f560bb161ff6b67f763c576'),
(57, 35, 'savings', 0.0, '28a1b310b43643306f560bb161ff6b67f763c576'),
(58, 36, 'savings', 2223323.32 ,'28a1b310b43643306f560bb161ff6b67f763c576'),
(59, 37, 'savings', -13.00 ,'28a1b310b43643306f560bb161ff6b67f763c576'),
(60, 38, 'savings', -1, '28a1b310b43643306f560bb161ff6b67f763c576'),
(61, 39, 'savings', 12323, '28a1b310b43643306f560bb161ff6b67f763c576'),
(62, 35, 'savings', 4553, '28a1b310b43643306f560bb161ff6b67f763c576'),
(63, 37, 'savings', 26086, '28a1b310b43643306f560bb161ff6b67f763c576');

INSERT INTO `TRANSACTION_HISTORY` (`ID`, `ACC_ID`, `TRANS_POSTDATE`, `TRANS_AMOUNT`, `STATE`) VALUES
(73, 56, NULL, 2200, 'PASS'),
(74, 60, NULL, -3001, 'PASS'),
(75, 63, NULL, 10000, 'PASS'),
(76, 56, NULL, -10000, 'FAIL'),
(77, 56, NULL, 200, 'PASS'),
(78, 61, NULL, -1030, 'FAIL'),
(79, 62, NULL, 6000, 'PASS');

INSERT INTO `CARD` (`ID`, `ACCOUNT_ID`, `TYPE_OF_CARD`, `EXP_DATE`, `PIN_CODE`, `CVV`) VALUES
(200, 56, 'VISA', '2015-01-14', '4231', '234'),
(201, 60, 'MASTER CARD' , '2012-01-14', '4231', '234'),
(202, 63, 'VISA',  '2020-01-14', '4433', '234'),
(203, 56, 'VISA',  '2050-01-14', '1231', '234'),
(204, 56, 'MASTER CARD',  '2032-01-14', '5231', '234'),
(205, 61, 'VISA',  '2020-01-14', '6732', '234'),
(206, 62, 'MASTER CARD', '2021-01-14', '0101', '234');

INSERT INTO `OPTIONS` (`CUSTOMER_ID`, `OPTION_NAME`) VALUES
(57, 'SMS'),
(60, 'AUTO PAYMENT'),
( 63, 'AUTO PAYMENT'),
( 55, 'SMS'),
(56, 'SMS'),
(61, 'AUTO PAYMENT'),
(62, 'SMS');