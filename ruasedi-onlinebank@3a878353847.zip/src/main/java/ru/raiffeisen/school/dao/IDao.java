package ru.raiffeisen.school.dao;

import org.hibernate.Session;

import java.io.Serializable;
import java.util.List;

public interface IDao<T extends Serializable> {
    void update(T t);
    void delete( T t);
    void insert( T t);
    List<T> findAll();
    T findById(long id);
}