package ru.raiffeisen.school.dao;

import ru.raiffeisen.school.model.TransactionHistory;

import javax.persistence.EntityManager;
import java.util.List;

public class TransactionHistoryDao implements IDao<TransactionHistory> {
    private static TransactionHistoryDao ourInstance = new TransactionHistoryDao();
    private static EntityManager entityManager;

    public static TransactionHistoryDao getInstance() {
        return ourInstance;
    }

    private TransactionHistoryDao() {
    }

    public static void setEntityManager(EntityManager entityManager) {
        ourInstance.entityManager = entityManager;
    }

    @Override
    public void update(TransactionHistory transactionHistory) {
        entityManager.merge(transactionHistory);
    }

    @Override
    public void delete(TransactionHistory transactionHistory) {
        entityManager.remove(transactionHistory);
    }

    @Override
    public void insert(TransactionHistory transactionHistory) {
        entityManager.persist(transactionHistory);
    }

    @Override
    public List<TransactionHistory> findAll() {
        return (List<TransactionHistory>)
                entityManager
                        .createQuery("select from TransactionHistory")
                        .getResultList();
    }

    @Override
    public TransactionHistory findById(long id) {
        return (TransactionHistory)
                entityManager
                        .createQuery("select from TransactionHistory where id = :id")
                        .setParameter("id", id)
                        .getSingleResult();
    }
}