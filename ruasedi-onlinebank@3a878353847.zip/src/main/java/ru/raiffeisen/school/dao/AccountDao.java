package ru.raiffeisen.school.dao;

import org.hibernate.Session;
import ru.raiffeisen.school.model.Account;

import javax.persistence.EntityManager;
import java.util.List;

public class AccountDao implements IDao<Account> {
    private static AccountDao ourInstance = new AccountDao();
    private static EntityManager entityManager;

    public static AccountDao getInstance() {
        return ourInstance;
    }

    private AccountDao() {
    }

    public static void setEntityManager(EntityManager entityManager) {
        ourInstance.entityManager = entityManager;
    }

    @Override
    public void update(Account account) {
        entityManager.merge(account);
    }

    @Override
    public void delete(Account account) {
        entityManager.remove(account);
    }

    @Override
    public void insert(Account account) {
        entityManager.persist(account);
    }

    @Override
    public List<Account> findAll() {
        return (List<Account>)
                entityManager
                        .createQuery("select from Account")
                        .getResultList();
    }

    @Override
    public Account findById(long id) {
        return (Account)
                entityManager
                        .createQuery("select from Account where id = :id")
                        .setParameter("id", id)
                        .getSingleResult();
    }
}