package ru.raiffeisen.school.dao;

import org.hibernate.Session;
import ru.raiffeisen.school.model.Card;

import javax.persistence.EntityManager;
import java.util.List;

public class CardDao implements IDao<Card> {
    private static CardDao ourInstance = new CardDao();
    private static EntityManager entityManager;

    public static CardDao getInstance() {
        return ourInstance;
    }

    private CardDao() {
    }

    public static void setEntityManager(EntityManager entityManager) {
        ourInstance.entityManager = entityManager;
    }

    @Override
    public void update(Card card) {
        entityManager.merge(card);
    }

    @Override
    public void delete(Card card) {
        entityManager.remove(card);
    }

    @Override
    public void insert(Card card) {
        entityManager.persist(card);
    }

    @Override
    public List<Card> findAll() {
        return (List<Card>)
                entityManager
                        .createQuery("select from Card")
                        .getResultList();
    }

    @Override
    public Card findById(long id) {
        return (Card)
                entityManager
                        .createQuery("select from Card where id = :id")
                        .setParameter("id", id)
                        .getSingleResult();
    }
}