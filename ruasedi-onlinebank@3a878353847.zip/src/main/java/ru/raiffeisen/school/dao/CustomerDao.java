package ru.raiffeisen.school.dao;

import org.hibernate.Session;
import ru.raiffeisen.school.model.Customer;

import javax.persistence.EntityManager;
import java.util.List;

public class CustomerDao implements IDao<Customer> {
    private static CustomerDao ourInstance = new CustomerDao();
    private static EntityManager entityManager;

    public static CustomerDao getInstance() {
        return ourInstance;
    }

    private CustomerDao() {
    }

    public static void setEntityManager(EntityManager entityManager) {
        ourInstance.entityManager = entityManager;
    }

    @Override
    public void update(Customer customer) {
        entityManager.merge(customer);
    }

    @Override
    public void delete(Customer customer) {
        entityManager.remove(customer);
    }

    @Override
    public void insert(Customer customer) {
        entityManager.persist(customer);
    }

    @Override
    public List<Customer> findAll() {
        return (List<Customer>)
                entityManager
                .createQuery("select from Customer")
                .getResultList();
    }

    @Override
    public Customer findById(long id) {
        return (Customer)
                entityManager
                        .createQuery("select from Customer where id = :id")
                        .setParameter("id", id)
                        .getSingleResult();
    }
}