package ru.raiffeisen.school.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import ru.raiffeisen.school.model.Option;

import javax.persistence.EntityManager;
import java.util.List;

public class OptionDao implements IDao<Option> {
    private static OptionDao ourInstance = new OptionDao();
    private static EntityManager entityManager;

    public static OptionDao getInstance() {
        return ourInstance;
    }

    private OptionDao() {
    }

    public static void setEntityManager(EntityManager entityManager) {
        ourInstance.entityManager = entityManager;
    }

    @Override
    public void update(Option option) {

    }

    @Override
    public void delete(Option option) {

    }

    @Override
    public void insert(Option option) {

    }

    @Override
    public List<Option> findAll() {
        return (List<Option>)
                entityManager
                        .createQuery("select from Option")
                        .getResultList();
    }

    @Override
    public Option findById(long id) {
        return (Option)
                entityManager
                        .createQuery("select from Option where id = :id")
                        .setParameter("id", id)
                        .getSingleResult();
    }
}
