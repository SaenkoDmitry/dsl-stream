package ru.raiffeisen.school.model;

import javax.persistence.*;
import java.io.Serializable;
import java.time.Instant;

@Entity
@Table(name = "card")
public class Card implements Serializable {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "account_id", nullable = false)
    private Account accountCard;

    @Column(name = "type_of_card", nullable = false)
    private String typeOfCard;

    @Column(name = "exp_date", nullable = false)
    private Instant expDate;

    @Column(name = "pin_code", nullable = false)
    private String pinCode;

    @Column(name = "cvv", nullable = false)
    private String cvv;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Account getAccountCard() {
        return accountCard;
    }

    public void setAccount(Account accountCard) {
        this.accountCard = accountCard;
    }

    public String getCvv() {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }

    public String getTypeOfCard() {
        return typeOfCard;
    }

    public void setTypeOfCard(String typeOfCard) {
        this.typeOfCard = typeOfCard;
    }

    public Instant getExpDate() {
        return expDate;
    }

    public void setExpDate(Instant expDate) {
        this.expDate = expDate;
    }

    public String getPinCode() {
        return pinCode;
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }

    public void setAccountCard(Account accountCard) {
        this.accountCard = accountCard;
    }

    @Override
    public String toString() {
        return "Card{" +
                "id=" + id +
                ", accountCard=" + accountCard +
                ", typeOfCard='" + typeOfCard + '\'' +
                ", expDate=" + expDate +
                ", pinCode='" + pinCode + '\'' +
                ", cvv='" + cvv + '\'' +
                '}';
    }
}