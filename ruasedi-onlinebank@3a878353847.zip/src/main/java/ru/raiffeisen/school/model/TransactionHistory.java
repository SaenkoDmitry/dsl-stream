package ru.raiffeisen.school.model;

import javax.persistence.*;
import java.io.Serializable;
import java.time.Instant;

@Entity
@Table(name = "transaction_history")
public class TransactionHistory implements Serializable {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "account_id", nullable = false)
    private Account accountTransactionHistory;

    @Column(name = "trans_postdate", nullable = false)
    private Instant timeOfOperation;

    @Column(name = "trans_desc", nullable = false)
    private Instant transDesc;

    @Column(name = "state", nullable = false)
    private String state;

    @Column(name = "trans_amount", nullable = false)
    private Instant transAmount;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Account getAccountTransactionHistory() {
        return accountTransactionHistory;
    }

    public void setAccountId(Account accountTransactionHistory) {
        this.accountTransactionHistory = accountTransactionHistory;
    }

    public Instant getTimeOfOperation() {
        return timeOfOperation;
    }

    public void setTimeOfOperation(Instant timeOfOperation) {
        this.timeOfOperation = timeOfOperation;
    }

    public Instant getTransDesc() {
        return transDesc;
    }

    public void setTransDesc(Instant transDesc) {
        this.transDesc = transDesc;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Instant getTransAmount() {
        return transAmount;
    }

    public void setTransAmount(Instant transAmount) {
        this.transAmount = transAmount;
    }

    public void setAccountTransactionHistory(Account accountTransactionHistory) {
        this.accountTransactionHistory = accountTransactionHistory;
    }

    @Override
    public String toString() {
        return "TransactionHistory{" +
                "id=" + id +
                ", accountTransactionHistory=" + accountTransactionHistory +
                ", timeOfOperation=" + timeOfOperation +
                ", transDesc=" + transDesc +
                ", state='" + state + '\'' +
                ", transAmount=" + transAmount +
                '}';
    }
}