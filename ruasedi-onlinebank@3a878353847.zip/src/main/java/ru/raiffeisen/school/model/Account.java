package ru.raiffeisen.school.model;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "account")
public class Account implements Serializable {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;

    @Column(name = "secret", nullable = false)
    private String secret;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customerAcc;

    @Column(name = "type_of_acc", nullable = false)
    private String typeOfAccount;

    @Column(name = "balance", nullable = false)
    private Long balance;

    @OneToMany(fetch = FetchType.EAGER, mappedBy = "accountCard")
    Set<Card> cards = new HashSet<>();

    @OneToMany(fetch = FetchType.EAGER, mappedBy = "accountTransactionHistory")
    Set<TransactionHistory> transactionHistories = new HashSet<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
}

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

    public Customer getCustomerAcc() {
        return customerAcc;
    }

    public void setCustomerAcc(Customer customerAcc) {
        this.customerAcc = customerAcc;
    }

    public String getTypeOfAccount() {
        return typeOfAccount;
    }

    public void setTypeOfAccount(String typeOfAccount) {
        this.typeOfAccount = typeOfAccount;
    }

    public Long getBalance() {
        return balance;
    }

    public void setBalance(Long balance) {
        this.balance = balance;
    }

    public Set<Card> getCards() {
        return cards;
    }

    public void setCards(Set<Card> cards) {
        this.cards = cards;
    }

    public Set<TransactionHistory> getTransactionHistories() {
        return transactionHistories;
    }

    public void setTransactionHistories(Set<TransactionHistory> transactionHistories) {
        this.transactionHistories = transactionHistories;
    }

    @Override
    public String toString() {
        return "Account{" +
                "id=" + id +
                ", secret='" + secret + '\'' +
                ", customerAcc=" + customerAcc +
                ", typeOfAccount='" + typeOfAccount + '\'' +
                ", balance=" + balance +
                ", cards=" + cards +
                ", transactionHistories=" + transactionHistories +
                '}';
    }
}