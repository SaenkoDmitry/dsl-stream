package ru.raiffeisen.school.model;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "option")
public class Option implements Serializable {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "customer_id")
    private Customer customerOption;

    @Column(name = "name_of_option", nullable = false)
    private String nameOfOption;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Customer getCustomerOption() {
        return customerOption;
    }

    public void setCustomerOption(Customer customerOption) {
        this.customerOption = customerOption;
    }

    public String getNameOfOption() {
        return nameOfOption;
    }

    public void setNameOfOption(String nameOfOption) {
        this.nameOfOption = nameOfOption;
    }

    @Override
    public String toString() {
        return "Option{" +
                "id=" + id +
                ", customerOption=" + customerOption +
                ", nameOfOption='" + nameOfOption + '\'' +
                '}';
    }
}