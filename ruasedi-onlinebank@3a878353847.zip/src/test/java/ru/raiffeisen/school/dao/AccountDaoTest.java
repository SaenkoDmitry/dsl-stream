package ru.raiffeisen.school.dao;

import org.h2.tools.RunScript;
import org.h2.tools.Server;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import javax.persistence.EntityManager;
import java.io.InputStreamReader;
import java.io.Reader;
import java.sql.Connection;
import java.sql.DriverManager;

public class AccountDaoTest {
    Server server;
    EntityManager entityManager;

    @BeforeMethod
    public void setUp() throws Exception {
        server = Server.createWebServer().start();
        entityManager = Database.createEntityManager();

        Class.forName("org.h2.Driver");
        try (
                Connection connection = DriverManager.getConnection("jdbc:h2:mem:myDb", "sa", "");
                Reader schemaReader = new InputStreamReader(getClass().getClassLoader().getResourceAsStream("schema.sql"));
                Reader generateDataReader = new InputStreamReader(getClass().getClassLoader().getResourceAsStream("generate_data.sql"))
                ) {
            RunScript.execute(connection, schemaReader);
//            RunScript.execute(connection, generateDataReader);
        }
        System.out.println(1);
    }

    @Test
    public void testUpdate() {
    }

    @Test
    public void testDelete() {
    }

    @Test
    public void testInsert() throws Exception {
        return;
//        Customer customer = new Customer();
//        customer.setFirstName("a");
//        customer.setLastName("b");
//        customer.setMiddleName("c");
//        customer.setGender('M');
//        customer.setMobile("911");
//        customer.setAddress("");
//        customer.setPassword("root");
//        customer.setEmail("1@mail.ru");
//        customer.setLogin("abc");
//        customer.setBirthday(LocalDate.now());
//
//        EntityTransaction txn = entityManager.getTransaction();
//        txn.begin();
//        CustomerDao.setEntityManager(entityManager);
//        CustomerDao.getInstance().insert(customer);
//        txn.commit();
    }

    @Test
    public void testFindAll() {
    }

    @Test
    public void testFindById() {
    }
}