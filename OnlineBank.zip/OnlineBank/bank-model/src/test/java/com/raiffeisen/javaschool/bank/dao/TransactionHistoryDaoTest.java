package com.raiffeisen.javaschool.bank.dao;

import com.raiffeisen.javaschool.bank.model.Account;
import com.raiffeisen.javaschool.bank.model.TransactionHistory;
import com.raiffeisen.javaschool.bank.conf.TestConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;
import java.time.Instant;
import java.util.List;

@ContextConfiguration(classes = TestConfiguration.class)
@ActiveProfiles("test")
public class TransactionHistoryDaoTest extends AbstractTestNGSpringContextTests {

    @Autowired
    private AccountDao accountDao;

    @Autowired
    private TransactionHistoryDao transactionHistoryDao;

    @Test(groups = "first")
    public void testFind() {
        TransactionHistory transactionHistory = transactionHistoryDao.findById(76L);
        Assert.assertEquals(transactionHistory.getId().longValue(), 76L);
    }

    @Test(groups = "third")
    public void testPersist() {
        TransactionHistory transactionHistory = new TransactionHistory();
        transactionHistory.setState("PASS");
        transactionHistory.setTimeOfOperation(Instant.now());
        transactionHistory.setTransDesc("");
        Account account = accountDao.findById(56L);
        transactionHistory.setAccountTransactionHistory(account);
        transactionHistory.setTransAmount(5L);

        int before = transactionHistoryDao.findAll().size();
        transactionHistoryDao.create(transactionHistory);
        int after = transactionHistoryDao.findAll().size();

        Assert.assertEquals(before + 1, after);
    }

    @Test(groups = "fourth")
    public void testDelete() {
        int before = transactionHistoryDao.findAll().size();
        transactionHistoryDao.delete(73L);
        int after = transactionHistoryDao.findAll().size();
        Assert.assertEquals(before - 1, after);
    }

    @Test(groups = "first")
    public void testFindAllByExpirationTimeAndAccountId() {
        List<TransactionHistory> histories = transactionHistoryDao
                .findAllByExpirationTimeAndAccountId(58L, Duration.ofDays(365 * 4));
        Assert.assertEquals(histories.size(), 3);

        //TODO fix logic (Actual: 0)
    }

    @Test(groups = "first")
    public void testGetAllByCardId() {
        List<TransactionHistory> histories = transactionHistoryDao.getAllByCardId(200L);
        Assert.assertEquals(histories.size(), 1);
    }
}