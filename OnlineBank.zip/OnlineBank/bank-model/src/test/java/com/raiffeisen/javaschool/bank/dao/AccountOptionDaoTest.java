package com.raiffeisen.javaschool.bank.dao;

import com.raiffeisen.javaschool.bank.conf.TestConfiguration;
import com.raiffeisen.javaschool.bank.model.AccountOption;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Collection;
import java.util.List;

import static org.testng.Assert.*;

@ContextConfiguration(classes = TestConfiguration.class)
@ActiveProfiles("test")
public class AccountOptionDaoTest extends AbstractTestNGSpringContextTests {

    @Autowired
    private AccountDao accountDao;

    @Autowired
    private AccountOptionDao accountOptionDao;

    @Test(groups = "first")
    public void testGetCustomerPhoneNumbersWithOption() {
        Collection<String> customerPhones = accountOptionDao.getCustomerPhoneNumbersWithOption("SMS", "AUTO PAYMENT");
        Assert.assertEquals(customerPhones.size(), 2);
    }

    @Test(groups = "first")
    public void testFindAll() {
        List<AccountOption> accountOptions = accountOptionDao.findAll();
        assertEquals(accountOptions.size(), 4);
    }

    @Test(groups = "first")
    public void testFindById() {
        AccountOption accountOption = accountOptionDao.findById(56L);
        assertNotNull(accountOption);
    }

    @Test(groups = "first")
    public void testUpdate() {
        AccountOption accountOption = accountOptionDao.findById(56L);
        accountOption.setNameOfOption("OLOLO");
        accountOptionDao.update(accountOption);
        assertEquals(accountOption.getNameOfOption(), "OLOLO");

    }

    @Test(groups = "third")
    public void testDelete() {
        int before = accountOptionDao.findAll().size();
        accountOptionDao.delete(59L);
        int after = accountOptionDao.findAll().size();
        Assert.assertEquals(before - 1, after);

    }

    @Test(groups = "second")
    public void testCreate() {
        AccountOption accountOption = new AccountOption();
        accountOption.setNameOfOption("temp");
        accountOption.setAccountOption(accountDao.findById(61L));

        accountOptionDao.create(accountOption);

    }

    @Test(groups = "first")
    public void getCustomerPhoneNumbersWithOptionTest() {
        Collection<String> sms = accountOptionDao.getCustomerPhoneNumbersWithOption("SMS");

        assertEquals(sms.size(), 2);

    }


}