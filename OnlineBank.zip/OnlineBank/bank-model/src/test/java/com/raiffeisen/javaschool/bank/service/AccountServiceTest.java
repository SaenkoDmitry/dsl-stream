package com.raiffeisen.javaschool.bank.service;

import static org.testng.Assert.*;

public class AccountServiceTest {

}