package com.raiffeisen.javaschool.bank.service;

import com.raiffeisen.javaschool.bank.conf.TestConfiguration;
import com.raiffeisen.javaschool.bank.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.annotations.Test;

import java.util.Map;

import static org.testng.Assert.*;

@Test(groups = "service-test")
@ContextConfiguration(classes = TestConfiguration.class)
public class CustomerServiceTest extends AbstractTestNGSpringContextTests {

    @Autowired
    CustomerService customerService;


    public void testFindCustomerByLogin() {
        Customer customer = customerService.findCustomerByLogin("LOGIN");
        assertEquals(customer.getFirstName(), "Vasiliy");
        assertEquals(customer.getLastName(), "Petrov");
    }

    @Test
    public void testGetSumBalanceOfCustomer() {
        Customer customer = customerService.findCustomerByLogin("LOGIN");
        long totalBalance = customerService.getSumBalanceOfCustomer(customer);

        assertEquals(totalBalance, 12342L);
    }

    @Test
    public void testGetSumBalanceForEachCustomerLogin() {
        Map<String, Long> loginSumBalanceMap = customerService.getSumBalanceForEachCustomerLogin();
        long sumBalance1 = loginSumBalanceMap.get("LOGIN1");
        long sumBalance2 = loginSumBalanceMap.get("LOGIN2");

        assertEquals(sumBalance1, 5L);
        assertEquals(sumBalance2, 2232323);

    }

    @Test
    public void testGetPercentOfCustomersRicherThanThis() {
        Customer customer = customerService.findCustomerByLogin("LOGIN");
        int percentOfCustomersRicherThanThis = customerService.getPercentOfCustomersRicherThanThis(customer);

        Customer customer1 = customerService.findCustomerByLogin("LOGIN1");
        int percentOfCustomersRicherThanThis1 = customerService.getPercentOfCustomersRicherThanThis(customer1);

        Customer customer2 = customerService.findCustomerByLogin("LOGIN2");
        int percentOfCustomersRicherThanThis2 = customerService.getPercentOfCustomersRicherThanThis(customer2);

        assertEquals(percentOfCustomersRicherThanThis, 37);
        assertEquals(percentOfCustomersRicherThanThis1, 100);
        assertEquals(percentOfCustomersRicherThanThis2, 12);


    }

    @Test
    public void testGetCustomerDescription() {
        Customer customer = customerService.findCustomerByLogin("LOGIN");
        assertEquals(customerService.getCustomerDescription(customer),
                "Приветствую, Vasiliy. " +
                        "Вы беднее, чем 37 процентов пользователей банка.");
    }

    @Test
    public void testGetNumberOfCustomersRicherThanThis() {
        Customer customer = customerService.findCustomerByLogin("LOGIN");
        long numberOfCustomersRicherThanThis = customerService.getNumberOfCustomersRicherThanThis(customer);
        assertEquals(numberOfCustomersRicherThanThis, 5);

    }
}