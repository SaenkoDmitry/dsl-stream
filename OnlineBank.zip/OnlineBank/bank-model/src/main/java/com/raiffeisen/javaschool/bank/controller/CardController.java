package com.raiffeisen.javaschool.bank.controller;

import com.raiffeisen.javaschool.bank.dao.CardDao;
import com.raiffeisen.javaschool.bank.model.Card;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequestMapping("cards")
public class CardController {
    @Autowired
    CardDao cardDao;

    @GetMapping(value = "/", produces = "application/json")
    public @ResponseBody
    List<Card> getCards() {
        List<Card> cards = cardDao.findAll();
        return cards;
    }

    @GetMapping("/{id}")
    public @ResponseBody
    ResponseEntity getCard(@PathVariable("id") Long id) {

        Card card = cardDao.findById(id);
        if (card == null) {
            return new ResponseEntity("No card found for id = " + id, HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity(card, HttpStatus.OK);
    }
}
