package com.raiffeisen.javaschool.bank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.AbstractEnvironment;

//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//@Configuration
//@ComponentScan(basePackageClasses = TestConfiguration.class, excludeFilters={
//        @ComponentScan.Filter(type=FilterType.ASSIGNABLE_TYPE, value=DevConfiguration.class),
//        @ComponentScan.Filter(type=FilterType.ASSIGNABLE_TYPE, value=PersistenceDevConfiguration.class)
//})
//@ActiveProfiles("dev")
@SpringBootApplication
public class Application {
//    @Bean
//    public BCryptPasswordEncoder bCryptPasswordEncoder() {
//        return new BCryptPasswordEncoder();
//    }

    public static void main(String[] args) {
        System.setProperty(AbstractEnvironment.ACTIVE_PROFILES_PROPERTY_NAME, "dev");
        SpringApplication.run(Application.class, args);
    }
}
