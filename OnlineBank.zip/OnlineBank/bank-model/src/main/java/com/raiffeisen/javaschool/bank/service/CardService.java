package com.raiffeisen.javaschool.bank.service;

import com.raiffeisen.javaschool.bank.model.Customer;
import com.raiffeisen.javaschool.bank.dao.CardDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CardService {

    @Autowired
    CardDao cardDao;

    public Customer findOwner(long id) {

        return cardDao.findOwner(id);
    }


}
