package com.raiffeisen.javaschool.bank.conf;

import org.springframework.core.env.Environment;

public class PropertyValidator {

    public static String getProperty(Environment env, String propertyName) {

        String property = env.getProperty(propertyName);

        if (property == null || property.isEmpty()) {
            throw new IllegalArgumentException("property " + propertyName + " must not be null");
        }
        return property;
    }}
