package com.raiffeisen.javaschool.bank.controller;

import com.raiffeisen.javaschool.bank.dao.AccountDao;
import com.raiffeisen.javaschool.bank.model.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/accounts")
public class AccountController {
    @Autowired
    private AccountDao accountDao;

    @Autowired
    public AccountController(AccountDao accountDao) {
        this.accountDao = accountDao;
    }

    @GetMapping(value = "/", produces = "application/json")
//    @PreAuthorize("hasAnyRole('admin','user')")
    public @ResponseBody
    List<Account> getAccounts() {
        List<Account> accounts = accountDao.findAll();
        return accounts;
    }

    @GetMapping("/{id}")
    public @ResponseBody
    ResponseEntity getCustomer(@PathVariable("id") Long id) {

        Account account = accountDao.findById(id);
        if (account == null) {
            return new ResponseEntity("No account found for id = " + id, HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity(account, HttpStatus.OK);
    }
}
