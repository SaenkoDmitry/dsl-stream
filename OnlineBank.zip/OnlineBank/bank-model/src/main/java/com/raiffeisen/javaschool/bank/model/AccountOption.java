package com.raiffeisen.javaschool.bank.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import java.io.Serializable;

@Data
@EqualsAndHashCode(exclude = "customerOption")

@Entity
@Table(name = "account_option", schema = "public")
public class AccountOption implements Serializable {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "account_id")
    private Account accountOption;

    @Column(name = "option_name", nullable = false)
    private String nameOfOption;

}
