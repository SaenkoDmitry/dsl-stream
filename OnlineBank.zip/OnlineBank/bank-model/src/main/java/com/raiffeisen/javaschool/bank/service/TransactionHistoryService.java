package com.raiffeisen.javaschool.bank.service;

import com.raiffeisen.javaschool.bank.dao.AccountDao;
import com.raiffeisen.javaschool.bank.dao.TransactionHistoryDao;
import com.raiffeisen.javaschool.bank.model.TransactionHistory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.List;

@Service
public class TransactionHistoryService {


    @Autowired
    private final TransactionHistoryDao transactionHistoryDao;

    @Autowired
    private final AccountDao accountDao;

    @Autowired
    public TransactionHistoryService(TransactionHistoryDao transactionHistoryDao, AccountDao accountDao) {
        this.accountDao = accountDao;
        this.transactionHistoryDao = transactionHistoryDao;
    }

    public List<TransactionHistory> findAllByExpirationTimeAndAccountId(Long id, Duration duration) {

        return transactionHistoryDao.findAllByExpirationTimeAndAccountId(id, duration);
    }

    public void print(Long id) {

//         transactionHistoryDao.getAllByCardId(id).stream()
//                 .forEach(m -> System.out::println(m));


    }

    public boolean tryMakeTransaction(String transDesc, String state, Long amount, Long idFrom, Long idTo) {
        Instant now = Instant.now();
        TransactionHistory transactionHistoryFrom = new TransactionHistory();
        TransactionHistory transactionHistoryTo = new TransactionHistory();

        Long fromBalance = - amount;
        Long toBalance = amount;

        transactionHistoryFrom.setTimeOfOperation(now);
        transactionHistoryFrom.setState(state);
        transactionHistoryFrom.setTransDesc(transDesc);
        transactionHistoryFrom.setTransAmount(fromBalance);

        transactionHistoryTo.setTimeOfOperation(now);
        transactionHistoryTo.setState(state);
        transactionHistoryTo.setTransDesc(transDesc);
        transactionHistoryFrom.setTransAmount(toBalance);

        Transaction txn = null;
        try  {
            txn = (Transaction) transactionHistoryDao.getEntityManager().getTransaction();
            transactionHistoryDao.create(transactionHistoryFrom);
            accountDao.changeBalance(idFrom, fromBalance);
            transactionHistoryDao.create(transactionHistoryTo);
            accountDao.changeBalance(idTo, toBalance);
            txn.commit();
            return true;
        } catch (RuntimeException e) {
//            log.error("Transaction failed.", e);
            if (txn != null && txn.isActive()) {
                txn.rollback();
            }
            return false;
        }
    }
}
