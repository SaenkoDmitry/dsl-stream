package com.raiffeisen.javaschool.bank.conf;

import com.raiffeisen.javaschool.bank.controller.AccountController;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
        import org.springframework.transaction.annotation.EnableTransactionManagement;

@Profile({"test", "dev"})
@Configuration
@EnableTransactionManagement
@ComponentScan(basePackageClasses = AccountController.class)
public class ControllerConfiguration {
}
