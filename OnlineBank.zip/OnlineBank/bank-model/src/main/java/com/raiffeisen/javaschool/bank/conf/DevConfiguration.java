package com.raiffeisen.javaschool.bank.conf;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Profile;

@Profile("dev")
@Configuration
//@Import({PersistenceDevConfiguration.class, ModelConfiguration.class})
public class DevConfiguration {

}
