package com.raiffeisen.javaschool.bank.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@Data
@EqualsAndHashCode(exclude = {"customerAcc", "transactionHistories", "options"})
@ToString(exclude = {"customerAcc", "cards", "transactionHistories", "options"})
@Entity
@Table(name = "account", schema = "public")
public class Account implements Serializable {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "secret", nullable = false)
    private String secret;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customerAcc;

    @Column(name = "type_of_acc", nullable = false)
    private String typeOfAccount;

    @Column(name = "balance", nullable = false)
    private Long balance; //TODO Change to BigDecimal(???)

    @OneToMany(cascade = CascadeType.REMOVE,
            fetch = FetchType.LAZY,
            orphanRemoval = true,
            mappedBy = "accountCard")
    private Set<Card> cards = new HashSet<>();

    @OneToMany(cascade = CascadeType.REMOVE,
            fetch = FetchType.LAZY,
            orphanRemoval = true,
            mappedBy = "accountTransactionHistory")
    private Set<TransactionHistory> transactionHistories = new HashSet<>();

    @OneToMany(cascade = CascadeType.REMOVE,
            fetch = FetchType.LAZY,
            orphanRemoval = true,
            mappedBy = "accountOption")
    Set<AccountOption> options = new HashSet<>();

}
