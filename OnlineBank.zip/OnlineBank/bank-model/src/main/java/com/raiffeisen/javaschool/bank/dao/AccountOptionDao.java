package com.raiffeisen.javaschool.bank.dao;

import com.raiffeisen.javaschool.bank.model.Account;
import com.raiffeisen.javaschool.bank.model.AccountOption;
import com.raiffeisen.javaschool.bank.model.Customer;
import org.springframework.stereotype.Repository;

import javax.persistence.criteria.*;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Repository
public class AccountOptionDao extends PagingAbstractDao<AccountOption> {
    @Override
    Class getEClass() {
        return AccountOption.class;
    }

    @Transactional
    public Collection<String> getCustomerPhoneNumbersWithOption(String... options) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<String> query = cb.createQuery(String.class);
        Root<Customer> from = query.from(Customer.class);

        Join<Customer, Account> accWithAccOption = from.join("accounts");
        Join<Account, AccountOption> join2 = accWithAccOption.join("options");

        List<Predicate> predicates = new ArrayList<>();
        for (int i = 0; i < options.length; i++) {
            predicates.add(cb.equal(join2.get("nameOfOption"), options[i]));
        }

        query
                .select(from.get("mobile").as(String.class))
                .groupBy(from.get("mobile"))
                .where(
                        cb.or(predicates.toArray(new Predicate[predicates.size()]))
                );

        return list(query);
    }
}
