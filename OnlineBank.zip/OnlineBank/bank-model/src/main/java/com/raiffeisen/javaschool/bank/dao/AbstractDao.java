package com.raiffeisen.javaschool.bank.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.List;

@Transactional(readOnly = true)
@Repository
public abstract class AbstractDao<E> {
    protected final Logger logger = LoggerFactory.getLogger(AbstractDao.class);

    /*protected Class eClass = (Class)((ParameterizedType)this
            .getClass().getGenericSuperclass()).getActualTypeArguments()[0]*/;
    @PersistenceContext
    protected EntityManager em;

    abstract Class getEClass();

    @Autowired
    public EntityManager getEntityManager() {
        return em;
    }

    public List<E> findAll() {
        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<E> query = cb.createQuery(getEClass());
        Root<E> from = query.from(getEClass());
        query.select(from);
        return getEntityManager().createQuery(query).getResultList();
    }

    public E findById(Long id) {
        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<E> query = cb.createQuery(getEClass());
        Root<E> from = query.from(getEClass());
        query.select(from).where(
                cb.equal(from.get("id"), id)
        );
        return getEntityManager().createQuery(query).getSingleResult();
    }

    @Transactional
    public void update(E entity) {
        getEntityManager().merge(entity);
    }

    @Transactional
    public void delete(Long id) {
        E eObj = (E) getEntityManager().find(getEClass(), id);
        if (eObj != null) {
            getEntityManager().remove(eObj);
        }
    }

    @Transactional
    public void create(E entity) {
        getEntityManager().persist(entity);
    }


    protected <X> List<X> list(CriteriaQuery<X> criteria) {
        return getEntityManager().createQuery(criteria).getResultList();
    }


    protected <X> X single(CriteriaQuery<X> criteria) {
        try {
            return getEntityManager().createQuery(criteria).getSingleResult();
        } catch (Exception ex) {
            return null;
        }
    }

    protected CriteriaQuery<E> baseSearch(SearchFilter searchFilter) {
        CriteriaBuilder criteriaBuilder = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<E> criteriaQuery = criteriaBuilder.createQuery(getEClass());
        Root<E> entityRoot = criteriaQuery.from(getEClass());
        criteriaQuery.select(entityRoot);
        criteriaQuery.where(searchFilter.buildPredicate(criteriaBuilder, entityRoot));
        return criteriaQuery;
    }


    protected List<E> searchList(SearchFilter searchFilter) {
        CriteriaQuery<E> listCriteriaQuery = baseSearch(searchFilter);
        return list(listCriteriaQuery);
    }

    protected E searchSingle(SearchFilter searchFilter) {
        CriteriaQuery<E> singleCriteriaQuery = baseSearch(searchFilter);
        return single(singleCriteriaQuery);
    }

    abstract class SearchFilter {
        abstract Predicate buildPredicate(CriteriaBuilder criteriaBuilder, Root<E> root);
    }

}
