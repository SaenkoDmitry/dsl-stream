package com.raiffeisen.javaschool.bank.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import java.io.Serializable;
import java.time.Instant;

@Data
@EqualsAndHashCode(exclude = "accountTransactionHistory")
@Entity
@Table(name = "transaction_history", schema = "public")
public class TransactionHistory implements Serializable {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "account_id", nullable = false)
    private Account accountTransactionHistory;

    @Column(name = "trans_postdate", nullable = true)
    private Instant timeOfOperation;

    @Column(name = "trans_desc", nullable = true)
    private String transDesc;

    @Column(name = "state", nullable = false)
    private String state;

    @Column(name = "trans_amount", nullable = false)
    private Long transAmount;

}