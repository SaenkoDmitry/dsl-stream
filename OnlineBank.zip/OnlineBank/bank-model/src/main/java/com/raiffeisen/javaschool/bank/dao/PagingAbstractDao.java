package com.raiffeisen.javaschool.bank.dao;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import java.util.List;

@Transactional(readOnly = true)
@Repository
abstract class PagingAbstractDao<E> extends AbstractDao<E> {
    protected Page<E> searchListByPage(SearchFilter searchFilter, int pageSize) {
        CriteriaQuery<E> listCriteriaQuery = baseSearch(searchFilter);

        Page<E> page = new Page<>();

        page.init(pageSize, listCriteriaQuery);
        return page;
    }

    class Page<E> {

        private CriteriaQuery<E> criteriaQuery;
        private int currentPage;
        private int maxResults;
        private int pageSize;


        public int getPageSize() {
            return pageSize;
        }

        public int getMaxPages() {
            return maxResults / pageSize;
        }

        public void init(int pageSize, CriteriaQuery<E> typedQuery) {
            this.pageSize = pageSize;
            this.criteriaQuery = typedQuery;
            currentPage = 0;

            CriteriaBuilder criteriaBuilder = em.getCriteriaBuilder();
            CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
            countQuery.select(criteriaBuilder.count(countQuery.from(getEClass())));
            maxResults = em.createQuery(countQuery).getSingleResult().intValue();
        }

        public List<E> getCurrentResults() {
            return em.createQuery(criteriaQuery)
                    .setFirstResult(currentPage++ * pageSize)
                    .setMaxResults(pageSize)
                    .getResultList();
        }

        public void next() {
            currentPage++;
        }

        public void previous() {
            currentPage--;
            if (currentPage < 0) {
                currentPage = 0;
            }
        }

        public int getCurrentPage() {
            return currentPage;
        }

        public void setCurrentPage(int currentPage) {
            this.currentPage = currentPage;
        }

        public boolean hasNext() {
            return (((float) maxResults) / (currentPage * pageSize)) > 1;
        }


    }


}
