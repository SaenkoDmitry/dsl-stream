package com.raiffeisen.javaschool.bank.conf;


import com.raiffeisen.javaschool.bank.service.CustomerService;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@ComponentScan(basePackageClasses = CustomerService.class)
public class ServiceConfiguration {
}
