package com.raiffeisen.javaschool.bank.controller;

import com.raiffeisen.javaschool.bank.dao.TransactionHistoryDao;
import com.raiffeisen.javaschool.bank.model.TransactionHistory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("transactions")
public class TransactionHistoryController {

    @Autowired
    private final TransactionHistoryDao transactionHistoryDao;

//    @Autowired
//    private final TransactionHistoryService transactionHistoryService;

    @Autowired
    public TransactionHistoryController(TransactionHistoryDao transactionHistoryDao/*,
                                        TransactionHistoryService transactionHistoryService*/) {
        this.transactionHistoryDao = transactionHistoryDao;
//        this.transactionHistoryService = transactionHistoryService;
    }

    @GetMapping(value = "/", produces = "application/json")
//    @PreAuthorize("hasAnyRole('admin','user')")
    public @ResponseBody
    List<TransactionHistory> getTransactions() {
        List<TransactionHistory> transactionHistories = transactionHistoryDao.findAll();
        return transactionHistories;
    }

    @GetMapping("/{id}")
    public @ResponseBody
    ResponseEntity getTransaction(@PathVariable("id") Long id) {

        TransactionHistory transactionHistory = transactionHistoryDao.findById(id);
        if (transactionHistory == null) {
            return new ResponseEntity("No customer found for id = " + id, HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity(transactionHistory, HttpStatus.OK);
    }

    @PostMapping("/")
    public @ResponseBody ResponseEntity executeTransaction(@PathVariable("description")  String transDesc,
                                                          @PathVariable("state")  String state,
                                                          @PathVariable("amount")  Long amount,
                                                          @PathVariable("from") Long idFrom,
                                                          @PathVariable("to") Long idTo) {

//        transactionHistoryService.tryMakeTransaction(transDesc, state, amount, idFrom, idTo);

        return new ResponseEntity(HttpStatus.OK);
    }
}