package com.raiffeisen.javaschool.bank.conf;

import com.raiffeisen.javaschool.bank.aspect.SimpleProfilerAspect;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@Configuration
@EnableAspectJAutoProxy
@ComponentScan(basePackageClasses = SimpleProfilerAspect.class)
public class AOPConfiguration {
}
