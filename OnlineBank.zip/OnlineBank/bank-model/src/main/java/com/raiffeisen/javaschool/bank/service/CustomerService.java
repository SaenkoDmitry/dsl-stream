package com.raiffeisen.javaschool.bank.service;

import com.raiffeisen.javaschool.bank.dao.CustomerDao;
import com.raiffeisen.javaschool.bank.model.Account;
import com.raiffeisen.javaschool.bank.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

@Service
public class CustomerService {

    @Autowired
    CustomerDao customerDao;

    public Customer findCustomerByLogin(String consumerLogin) {
        return customerDao.findAll().stream()
                .filter(cust -> cust.getLogin().equals(consumerLogin))
                .findAny()
                .orElseThrow(() -> new NoSuchElementException("No customer with such login found"));
    }

    public long getSumBalanceOfCustomer(Customer customer) {
        return customer.getAccounts().stream()
                .map(Account::getBalance)
                .reduce(0L, (acc, b) -> acc + b);
    }

    public Map<String, Long> getSumBalanceForEachCustomerLogin() {
        return customerDao.findAll().stream()
                .collect(Collectors.groupingBy(
                        Customer::getLogin, Collectors.summingLong(this::getSumBalanceOfCustomer)));

        //TODO Спросить у Миши про Customer::getLogin
    }

    public long getNumberOfCustomersRicherThanThis(Customer customer) {
        long sumBalanceOfCustomer = getSumBalanceOfCustomer(customer);
        return getSumBalanceForEachCustomerLogin().values().stream()
                .filter(m -> (m < sumBalanceOfCustomer))
                .count();
    }

    public int getPercentOfCustomersRicherThanThis(Customer consideredCustomer) {
        Map<String, Long> consumerLoginSumBalanceMap = getSumBalanceForEachCustomerLogin();
        double numberOfConsumers = consumerLoginSumBalanceMap.size();
        double numberOfCustomersRicherThanThis = getNumberOfCustomersRicherThanThis(consideredCustomer);

        return (int) ((numberOfConsumers - numberOfCustomersRicherThanThis) / numberOfConsumers * 100);

    }

    public String getCustomerDescription(Customer customer) {

        int percent = getPercentOfCustomersRicherThanThis(customer);

        if (percent > 90) {
            return String.format("Ты беднее, чем %d процентов " +
                    "пользователей банка. " +
                    "Найди нормальную работу, нищеброд.", percent).trim();
        } else if ((percent > 20) && (percent <= 90)) {
            return String.format("Приветствую, %s. " +
                    "Вы беднее, чем %d процентов " +
                    "пользователей банка.", customer.getFirstName(), percent).trim();
        } else {
            return String.format("Здравствуйте, многоуважаемый %s %s. " +
                            "Вы богаче %d процентов " +
                            "пользователей банка. ", customer.getFirstName(),
                    customer.getMiddleName(), 100 - percent).trim();
        }

    }

}
