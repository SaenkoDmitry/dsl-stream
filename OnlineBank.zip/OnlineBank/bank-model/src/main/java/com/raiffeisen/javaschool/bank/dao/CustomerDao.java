package com.raiffeisen.javaschool.bank.dao;

import com.raiffeisen.javaschool.bank.model.Customer;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;

@Repository
public class CustomerDao extends PagingAbstractDao<Customer> {
    @Override
    Class getEClass() {
        return Customer.class;
    }

    @Transactional
    public void setAddress(long id, String address) {
        Customer customer = getEntityManager().find(Customer.class, id);
        if (customer != null) {
            customer.setAddress(address);
        }
    }
}
