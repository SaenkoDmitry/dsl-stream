package com.raiffeisen.javaschool.bank.dao;

import com.raiffeisen.javaschool.bank.model.Account;
import com.raiffeisen.javaschool.bank.model.Card;
import com.raiffeisen.javaschool.bank.model.Customer;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.time.LocalDate;
import java.util.List;

@Repository
public class AccountDao extends PagingAbstractDao<Account> {
    @Override
    Class getEClass() {
        return Account.class;
    }

    @Transactional
    public void changeBalance(long id, long balance) {
        Account acc = em.find(Account.class, id);
        if (acc != null) {
            acc.setBalance(acc.getBalance() + balance);
        }
    }

    public List<Account> findAllByNonActiveCard() {
        return searchList(new SearchFilter() {
            @Override
            public Predicate buildPredicate(CriteriaBuilder criteriaBuilder, Root<Account> root) {
                LocalDate currDate = LocalDate.now();
                Join<Account, Card> join = root.join("cards");
                return criteriaBuilder.lessThan(join.get("expDate"), currDate);
            }
        });
    }


    public List<Account> findAllByBirthdayNow() {
        return searchList(new SearchFilter() {
            @Override
            public Predicate buildPredicate(CriteriaBuilder criteriaBuilder, Root<Account> root) {
                LocalDate currDate = LocalDate.now();
                Join<Account, Customer> join = root.join("customerAcc");
                return criteriaBuilder.equal(join.get("birthday"), currDate);
            }
        });
    }

    public List<Account> findAllWithNegativeBalance() {
        return searchList(new SearchFilter() {
            @Override
            public Predicate buildPredicate(CriteriaBuilder criteriaBuilder, Root<Account> root) {
                return criteriaBuilder.lt(root.get("balance"), 0);
            }
        });
    }

    public Page<Account> findAccounts(int pageSize) {
        return searchListByPage(new SearchFilter() {
            @Override
            public Predicate buildPredicate(CriteriaBuilder criteriaBuilder, Root<Account> root) {
                return criteriaBuilder.isNotNull(root.get("balance"));
            }
        }, pageSize);
    }


}
