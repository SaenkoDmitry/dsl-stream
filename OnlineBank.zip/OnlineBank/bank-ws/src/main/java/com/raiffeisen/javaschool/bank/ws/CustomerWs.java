package com.raiffeisen.javaschool.bank.ws;

import com.raiffeisen.javaschool.bank.dao.CustomerDao;
import com.raiffeisen.javaschool.bank.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

@Component
@WebService(serviceName = "CustomerWS")
public class CustomerWs {
    @Autowired
    CustomerDao customerDao;

    @WebMethod(operationName = "getCustomers")
    public String getCustomers(@WebParam(name = "id") Long id) {
        return customerDao.findById(id)
                .getFirstName();
    }
}
