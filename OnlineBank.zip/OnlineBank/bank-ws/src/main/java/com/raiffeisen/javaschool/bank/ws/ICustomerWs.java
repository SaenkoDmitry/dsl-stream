package com.raiffeisen.javaschool.bank.ws;

import javax.jws.WebParam;

public interface ICustomerWs {
    String getCustomers(@WebParam(name = "id") String id);
}
