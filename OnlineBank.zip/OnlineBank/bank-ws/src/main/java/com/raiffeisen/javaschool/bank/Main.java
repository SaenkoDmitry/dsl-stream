package com.raiffeisen.javaschool.bank;

import com.raiffeisen.javaschool.bank.conf.CoreConfiguration;
import org.apache.cxf.transport.servlet.CXFServlet;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;

import javax.servlet.ServletContext;
import javax.servlet.ServletRegistration;

public class Main implements WebApplicationInitializer {

    @Override
    public void onStartup(ServletContext servletContext) {
        // Create the 'root' Spring application context
        AnnotationConfigWebApplicationContext rootCtx = new AnnotationConfigWebApplicationContext();
        rootCtx.register(CoreConfiguration.class);

        // Manage the lifecycle of the root application context
        servletContext.addListener(new ContextLoaderListener(rootCtx));

        ServletRegistration.Dynamic dispatcher = servletContext.addServlet("dispatcher", new CXFServlet());
        dispatcher.addMapping("/services/*");
        dispatcher.setLoadOnStartup(1);




    }
}