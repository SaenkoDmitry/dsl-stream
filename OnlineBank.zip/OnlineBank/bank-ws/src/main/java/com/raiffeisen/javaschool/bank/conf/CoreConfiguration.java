package com.raiffeisen.javaschool.bank.conf;

import com.raiffeisen.javaschool.bank.ws.CustomerWs;
import org.apache.cxf.Bus;
import org.apache.cxf.bus.spring.SpringBus;
import org.apache.cxf.jaxws.EndpointImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import javax.xml.ws.Endpoint;

@Configuration
@Import(TestConfiguration.class)
@ComponentScan(basePackageClasses = CustomerWs.class)
public class CoreConfiguration {
    @Autowired
    CustomerWs customerWs;

    @Bean(name = Bus.DEFAULT_BUS_ID)
    public SpringBus springBus() {
        return new SpringBus();
    }

    @Bean
    public Endpoint endpoint() {
        EndpointImpl endpoint = new EndpointImpl(springBus(), customerWs);
        endpoint.publish("http://localhost:8081/services/customerWs");
        return endpoint;
    }
}
